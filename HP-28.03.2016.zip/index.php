 <?php $titrepage="Accueil";
 $titresouspage="";
 include "entete.php"; 
 ?>
		
	<body>	
	
	<div class="starter-template">
		<h1><?php echo ($titrepage)?></h1>
    </div>
	
	<header>
	<h2>Bienvenue sur Huntington-Parkinson</h2>
	<p>La maladie de Parkinson et la maladie de Huntington sont toutes deux des pathologies
	neurodégénératives en lien avec le système dopaminergique, et plus particulièrement les
	ganglions de la base.</p>
		
	</header>
	
	</body>
	
	<?php include "pied.php";?> 
	 <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
