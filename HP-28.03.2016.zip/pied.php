  <footer>
  <p align="center">Ceci est un pied de page.</p>
  </footer>
  
</html>
